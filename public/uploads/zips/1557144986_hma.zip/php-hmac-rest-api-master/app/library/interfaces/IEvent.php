<?php

namespace Interfaces;

interface IEvent {

	public function handleEvent();
}
