<?php

namespace Models;

class Api extends \Phalcon\Mvc\Model {

	public $client_id;

	public $private_key;

	public $status;
}
